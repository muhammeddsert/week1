﻿// See https://aka.ms/new-console-template for more information

string myName = "Vladislav";

//Console.WriteLine("Hello " + myName);

Console.WriteLine($"Hello,{myName}!");